DYNAMIC ISLAND - CONTROL CENTER UI

UI diperbarui mengikuti referensi Control Center: panel gelap membulat, shortcut bulat, kartu Wi-Fi/Bluetooth/Hotspot/Lyrics, tombol sistem, slider tampilan kecerahan/volume, dan footer pemutar musik.

CARA MEMASANG
1. Tutup Dynamic Island jika sedang berjalan.
2. Ekstrak ZIP ini.
3. Salin folder src dan Cargo.toml ke C:\dynamic-island-win, ganti file lama jika diminta.
4. CMD:
   cd /d C:\dynamic-island-win
   cargo build --release
5. Jalankan:
   target\release\dynamic-island-win.exe

CATATAN
- Wi-Fi, Bluetooth, hotspot, brightness dan settings membuka halaman pengaturan Windows.
- Slider brightness hanya membuka pengaturan layar; tidak mengubah brightness hardware langsung.
- Slider volume mengirim volume-up/down ketika diklik di sisi kanan/kiri; tidak menetapkan nilai volume kontinu.
- Tombol screenshot membuka shortcut Windows + Shift + S.
- Build belum diverifikasi pada Windows dari lingkungan ini.
