@echo off
setlocal
set "TARGET=C:\dynamic-island-win"
echo Menyiapkan proyek Dynamic Island ke %TARGET% ...
if not exist "%~dp0Cargo.toml" (
  echo ERROR: Cargo.toml tidak ditemukan di folder paket ini.
  pause
  exit /b 1
)
if not exist "%~dp0src\main.rs" (
  echo ERROR: src\main.rs tidak ditemukan di folder paket ini.
  pause
  exit /b 1
)
if not exist "%TARGET%\src" mkdir "%TARGET%\src"
copy /Y "%~dp0Cargo.toml" "%TARGET%\Cargo.toml" >nul
if errorlevel 1 goto fail
copy /Y "%~dp0src\main.rs" "%TARGET%\src\main.rs" >nul
if errorlevel 1 goto fail
echo.
echo Berhasil menyalin Cargo.toml dan src\main.rs.
echo Sekarang jalankan perintah berikut di CMD:
echo cd /d C:\dynamic-island-win
echo cargo build --release
echo.
pause
exit /b 0
:fail
echo Gagal menyalin file. Coba jalankan setup.bat dengan Run as administrator.
pause
exit /b 1
